## 0x16. API advanced
