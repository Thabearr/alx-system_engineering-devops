## 0x06. Regular expression
