#!/usr/bin/env ruby
puts ARGV[0].scan(/Holberton/).join
