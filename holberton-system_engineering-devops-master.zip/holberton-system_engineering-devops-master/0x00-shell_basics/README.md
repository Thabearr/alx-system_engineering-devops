## 0x00. Shell, basics

**This project is about the basics of shell and bash programming**
