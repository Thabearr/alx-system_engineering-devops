## 0x02. Shell, I/O Redirections and filters
**This project is about unix standard i/o, redirection, filters, piping, and other related commands**