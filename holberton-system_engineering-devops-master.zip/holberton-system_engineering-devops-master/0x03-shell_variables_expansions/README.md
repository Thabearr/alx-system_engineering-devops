## 0x03-shell_variables_expansions

**This project is about Shell, init files, variables and expansions**
