## 0x1A. Application server
