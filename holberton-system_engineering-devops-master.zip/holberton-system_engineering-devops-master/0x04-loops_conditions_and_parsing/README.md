## 0x04. Loops, conditions and parsing
