## 0x11. What happens when you type holbertonschool.com in your browser and press Enter
